
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getWorkoutAdvice = async (goal: string, level: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Como experto entrenador de Vitalando Gym, crea una rutina rápida de 3 ejercicios para un usuario con objetivo "${goal}" y nivel "${level}". Responde en español de forma motivadora.`,
      config: {
        temperature: 0.7,
      }
    });
    return response.text;
  } catch (error) {
    console.error("Error fetching AI advice:", error);
    return "Lo siento, nuestro entrenador IA está descansando. Intenta de nuevo en unos minutos.";
  }
};
