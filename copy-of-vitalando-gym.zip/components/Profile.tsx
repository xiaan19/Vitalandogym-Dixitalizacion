
import React, { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { getWorkoutAdvice } from '../services/geminiService';
import { SCHEDULE } from '../constants';

const MOCK_PROGRESS_DATA = [
  { name: 'Sem 1', peso: 85, entrenos: 3 },
  { name: 'Sem 2', peso: 84.5, entrenos: 4 },
  { name: 'Sem 3', peso: 83.8, entrenos: 2 },
  { name: 'Sem 4', peso: 84.0, entrenos: 5 },
  { name: 'Sem 5', peso: 83.2, entrenos: 4 },
  { name: 'Sem 6', peso: 82.5, entrenos: 6 },
];

interface ProfileProps {
  bookedClassIds: string[];
  onToggleBooking: (id: string) => void;
}

const Profile: React.FC<ProfileProps> = ({ bookedClassIds, onToggleBooking }) => {
  const [advice, setAdvice] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchAIAdvice = async () => {
    setLoading(true);
    const text = await getWorkoutAdvice("Mejorar mi condición física general y aprender inglés", "Avanzado");
    setAdvice(text);
    setLoading(false);
  };

  useEffect(() => {
    fetchAIAdvice();
  }, []);

  const bookedClasses = SCHEDULE.filter(item => bookedClassIds.includes(item.id));

  return (
    <div className="py-20 px-6 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-8">
          <div className="glass p-8 rounded-3xl text-center border-t-4 border-cyan-400">
            <div className="w-32 h-32 mx-auto mb-6 rounded-full border-4 border-orange-500 overflow-hidden shadow-xl shadow-orange-500/10">
              <img src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=200&h=200&auto=format&fit=crop" alt="Avatar" className="w-full h-full object-cover" />
            </div>
            <h2 className="text-2xl font-bold mb-1">Alex Gómez</h2>
            <p className="text-gray-500 text-sm mb-6">Socio Vitalando #8291</p>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                <div className="text-xs text-cyan-400 font-bold uppercase">Peso</div>
                <div className="text-xl font-bold">82.5 kg</div>
              </div>
              <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                <div className="text-xs text-orange-500 font-bold uppercase">Meta</div>
                <div className="text-xl font-bold">78.0 kg</div>
              </div>
            </div>
          </div>

          <div className="glass p-8 rounded-3xl border-l-4 border-cyan-400 bg-cyan-400/5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-cyan-400">Coach IA Vitalando</h3>
              <span className="animate-pulse bg-cyan-400/20 text-cyan-400 text-[10px] px-2 py-0.5 rounded-full font-bold">ACTIVO</span>
            </div>
            {loading ? (
              <p className="text-gray-400 text-sm animate-pulse">Consultando tu plan bilingüe...</p>
            ) : (
              <div className="text-sm text-gray-300 leading-relaxed italic">
                "{advice || "Analizando tus progresos para optimizar tu entreno..."}"
              </div>
            )}
            <button 
              onClick={fetchAIAdvice}
              className="mt-6 text-xs text-orange-500 font-bold uppercase hover:text-orange-400 transition-colors flex items-center gap-2"
            >
              Actualizar Plan <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12a9 9 0 0 1-9 9m9-9a9 9 0 0 0-9-9m9 9H3m9 9a9 9 0 0 1-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9"/></svg>
            </button>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-8">
          <div className="glass p-8 rounded-3xl">
            <h3 className="text-xl font-bold mb-8">Evolución de Peso <span className="text-cyan-400">Progreso</span></h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={MOCK_PROGRESS_DATA}>
                  <defs>
                    <linearGradient id="colorPeso" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#22d3ee" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#22d3ee" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                  <XAxis dataKey="name" stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis domain={['auto', 'auto']} stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid rgba(34,211,238,0.2)', borderRadius: '12px' }}
                    itemStyle={{ color: '#22d3ee' }}
                  />
                  <Area type="monotone" dataKey="peso" stroke="#22d3ee" fillOpacity={1} fill="url(#colorPeso)" strokeWidth={3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass p-8 rounded-3xl">
              <h4 className="font-bold mb-4 text-orange-500">Mis Reservas</h4>
              <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2 scrollbar-hide">
                {bookedClasses.length > 0 ? (
                  bookedClasses.map(cls => (
                    <div key={cls.id} className="group flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:border-cyan-400/30 transition-all">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 rounded-xl bg-cyan-400/10 text-cyan-400 flex items-center justify-center font-bold text-xs uppercase">
                          {cls.day.substring(0, 2)}
                        </div>
                        <div>
                          <div className="text-sm font-bold text-white">{cls.title}</div>
                          <div className="text-xs text-gray-500">{cls.time} • {cls.trainer}</div>
                        </div>
                      </div>
                      <button 
                        onClick={() => onToggleBooking(cls.id)}
                        className="opacity-0 group-hover:opacity-100 p-2 text-red-400 hover:bg-red-400/10 rounded-lg transition-all"
                        title="Cancelar Reserva"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                      </button>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-10 opacity-40">
                    <p className="text-sm">No tienes clases reservadas aún.</p>
                  </div>
                )}
              </div>
            </div>

            <div className="glass p-8 rounded-3xl flex flex-col justify-center items-center relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="#22d3ee" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3h12l4 6-10 13L2 9z"/></svg>
              </div>
              <div className="relative w-36 h-36 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90">
                  <circle cx="72" cy="72" r="66" stroke="currentColor" strokeWidth="10" fill="transparent" className="text-white/5" />
                  <circle cx="72" cy="72" r="66" stroke="currentColor" strokeWidth="10" fill="transparent" strokeDasharray="414.7" strokeDashoffset={414.7 - (414.7 * (bookedClasses.length / 5))} className="text-orange-500 transition-all duration-1000" />
                </svg>
                <div className="absolute text-center">
                  <div className="text-3xl font-black text-white">{Math.min(100, (bookedClasses.length / 5) * 100).toFixed(0)}%</div>
                  <div className="text-[10px] text-orange-500 uppercase tracking-widest font-bold">Objetivo</div>
                </div>
              </div>
              <p className="mt-8 text-sm text-gray-400 text-center italic max-w-[200px]">
                {bookedClasses.length === 0 
                  ? "¡Reserva tu primera clase para empezar tu evolución!"
                  : `¡Vas por buen camino! Llevas ${bookedClasses.length} clases reservadas esta semana.`}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
