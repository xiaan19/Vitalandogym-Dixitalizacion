
import React, { useState } from 'react';
import { SCHEDULE, DAYS } from '../constants';

interface CalendarProps {
  bookedClassIds: string[];
  onToggleBooking: (id: string) => void;
}

const Calendar: React.FC<CalendarProps> = ({ bookedClassIds, onToggleBooking }) => {
  const [selectedDay, setSelectedDay] = useState('Lunes');

  const filteredActivities = SCHEDULE.filter(a => a.day === selectedDay);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'English Classes': return 'text-orange-500 bg-orange-500/10';
      case 'Yoga': return 'text-cyan-400 bg-cyan-400/10';
      case 'Crossfit': return 'text-red-400 bg-red-400/10';
      default: return 'text-cyan-400 bg-cyan-400/10';
    }
  };

  return (
    <div className="py-20 px-6 max-w-6xl mx-auto">
      <h2 className="text-4xl font-bold mb-8 text-center bg-gradient-to-r from-cyan-400 to-orange-500 bg-clip-text text-transparent">Horario de Actividades</h2>
      
      <div className="flex overflow-x-auto space-x-4 mb-12 pb-4 scrollbar-hide justify-center">
        {DAYS.map(day => (
          <button
            key={day}
            onClick={() => setSelectedDay(day)}
            className={`px-6 py-2 rounded-full whitespace-nowrap transition-all border ${
              selectedDay === day 
                ? 'bg-cyan-400 text-black border-cyan-400 font-bold shadow-lg shadow-cyan-400/20' 
                : 'bg-white/5 border-transparent hover:border-white/20 text-gray-400'
            }`}
          >
            {day}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredActivities.length > 0 ? (
          filteredActivities.map(activity => {
            const isBooked = bookedClassIds.includes(activity.id);
            return (
              <div 
                key={activity.id} 
                className={`glass p-6 rounded-2xl border transition-all group ${
                  isBooked ? 'border-orange-500/60 shadow-lg shadow-orange-500/5' : 'border-white/5 hover:border-cyan-400/50'
                }`}
              >
                <div className="flex justify-between items-start mb-4">
                  <span className={`text-xs font-bold uppercase tracking-widest px-2 py-1 rounded ${getCategoryColor(activity.category)}`}>
                    {activity.category}
                  </span>
                  <span className="text-gray-400 font-mono">{activity.time}</span>
                </div>
                <h3 className="text-xl font-bold mb-2 group-hover:text-cyan-400 transition-colors">{activity.title}</h3>
                <p className="text-gray-400 text-sm">Entrenador: <span className="text-white">{activity.trainer}</span></p>
                <button 
                  onClick={() => onToggleBooking(activity.id)}
                  className={`mt-6 w-full py-3 rounded-xl text-sm font-bold transition-all border ${
                    isBooked 
                      ? 'bg-orange-500 text-white border-orange-500 hover:bg-orange-600' 
                      : 'bg-white/5 border-white/10 hover:border-orange-500 hover:bg-orange-500/10 text-white'
                  }`}
                >
                  {isBooked ? 'Cancelar Reserva' : 'Reservar Clase'}
                </button>
              </div>
            );
          })
        ) : (
          <div className="col-span-full text-center py-20 bg-white/5 rounded-3xl border border-dashed border-white/10">
            <p className="text-gray-500">Día de descanso activo o eventos especiales.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Calendar;
