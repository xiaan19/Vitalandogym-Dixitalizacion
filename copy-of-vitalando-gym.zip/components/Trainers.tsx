
import React from 'react';
import { TRAINERS } from '../constants';

const Trainers: React.FC = () => {
  return (
    <div className="py-20 px-6 bg-[#0c0c0c]">
      <div className="max-w-7xl mx-auto">
        <div className="mb-16 text-center">
          <h2 className="text-5xl font-black mb-4 tracking-tight">Nuestros <span className="text-cyan-400">Técnicos</span></h2>
          <p className="text-gray-500 max-w-2xl mx-auto">Un equipo de élite para llevarte al siguiente nivel, incluyendo nuestras exclusivas clases en inglés con Montse.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
          {TRAINERS.map(trainer => (
            <div key={trainer.id} className="flex flex-col group cursor-pointer glass rounded-3xl overflow-hidden border-transparent hover:border-cyan-400/30 transition-all">
              <div className="relative overflow-hidden aspect-[4/5]">
                <img 
                  src={trainer.image} 
                  alt={trainer.name} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/20 to-transparent opacity-80"></div>
                <div className="absolute bottom-6 left-6 right-6">
                  <div className={`text-xs font-bold uppercase tracking-wider mb-2 ${trainer.name === 'Montse' ? 'text-orange-500' : 'text-cyan-400'}`}>
                    {trainer.specialty}
                  </div>
                  <div className="text-2xl font-bold">{trainer.name}</div>
                </div>
              </div>
              <div className="p-6">
                <p className="text-gray-400 text-sm leading-relaxed">
                  {trainer.bio}
                </p>
                <div className="mt-6 flex gap-4">
                   <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center hover:bg-cyan-400/20 hover:text-cyan-400 transition-colors">
                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                   </div>
                   <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center hover:bg-orange-500/20 hover:text-orange-500 transition-colors">
                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
                   </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Trainers;
