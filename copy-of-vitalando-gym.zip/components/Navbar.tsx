
import React from 'react';

interface NavbarProps {
  onNavigate: (section: string) => void;
  activeSection: string;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, activeSection }) => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/10 px-6 py-4 flex items-center justify-between">
      <div 
        className="text-2xl font-extrabold tracking-tighter text-cyan-400 cursor-pointer"
        onClick={() => onNavigate('home')}
      >
        VITALANDO<span className="text-orange-500">GYM</span>
      </div>
      <div className="hidden md:flex items-center space-x-8">
        {['Inicio', 'Calendario', 'Técnicos', 'Perfil'].map((item) => (
          <button
            key={item}
            onClick={() => onNavigate(item.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""))}
            className={`text-sm font-medium transition-colors hover:text-cyan-400 ${
              activeSection === item.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "") ? 'text-cyan-400' : 'text-gray-400'
            }`}
          >
            {item}
          </button>
        ))}
      </div>
      <button 
        onClick={() => onNavigate('perfil')}
        className="bg-orange-500 text-white px-6 py-2 rounded-full text-sm font-bold hover:bg-orange-600 transition-colors shadow-lg shadow-orange-500/20"
      >
        ENTRAR
      </button>
    </nav>
  );
};

export default Navbar;
